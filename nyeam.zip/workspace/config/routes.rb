Rails.application.routes.draw do

  
  root 'logins#index'
  resources :logins
	devise_scope :admin do
	  authenticated :admin do
	    root 'products#index', as: :authenticated_root
	    resources :products do
	    	collection do
	    		get :reports, as: 'reports', to: 'products'
	    	end
	    end
	    resources :cashiers, except: :destroy  do
	    	member do 
    			get :deactivate, to: 'cashiers#deactivate'
	  		end
	  	end	
	  end
	  

	    unauthenticated do
	    root 'devise/sessions#new', as: :unauthenticated_root
	  end
	end
	
	devise_scope :cashier do
	  authenticated :cashier do
		resources :orders, except: :tempcreate do
			collection do
				post :tempcreate, as: 'tempcreate' ,to: 'orders#tempcreate'
				end
			end
		end
	end
	
	devise_scope :customer do
	    authenticated :customer do
            get 'customer/index'
                resources :products, except: :show do
                    collection do
                        post :show, as: 'show' ,to: 'show#product'
                    
                end
            end
	    end
	end
	
	devise_for :cashiers
	devise_for :admins
	devise_for :customers
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
