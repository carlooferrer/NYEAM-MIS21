require 'test_helper'

class OrderlinesControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get orderlines_index_url
    assert_response :success
  end

end
