require 'test_helper'

class CashiersControllerTest < ActionDispatch::IntegrationTest
  test "should get new" do
    get cashiers_new_url
    assert_response :success
  end

end
