require 'test_helper'

class CashierTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
