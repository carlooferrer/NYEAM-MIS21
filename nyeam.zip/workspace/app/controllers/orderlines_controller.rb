class OrderlinesController < ApplicationController
  def index
  end
end
