class LoginsController < ApplicationController
  def index
  end
end
