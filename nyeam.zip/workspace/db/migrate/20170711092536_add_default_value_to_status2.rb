class AddDefaultValueToStatus2 < ActiveRecord::Migration[5.1]
  def change
    change_column :products, :status, :boolean, default: :true
  end
end
