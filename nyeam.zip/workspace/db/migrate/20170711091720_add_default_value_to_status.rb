class AddDefaultValueToStatus < ActiveRecord::Migration[5.1]
  def change
    change_column :cashiers, :status, :boolean, default: :true
  end
end
